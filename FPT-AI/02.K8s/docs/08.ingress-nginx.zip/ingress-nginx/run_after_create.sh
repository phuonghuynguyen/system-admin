#!/usr/bin/env bash
kubectl delete -A ValidatingWebhookConfiguration ingress-nginx-admission